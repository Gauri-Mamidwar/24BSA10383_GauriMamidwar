package com.example.collegemanagementsystem.domain;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

@Document(collection = "system_users")
public class SecureUserRegistry {
    @Id
    private String userId;
    private String username;
    private String encryptedPassword;
    private String securityRole; // ADMIN, FACULTY, STUDENT
    private Boolean isAccountActive;

    public SecureUserRegistry() {}

    public SecureUserRegistry(String username, String encryptedPassword, String securityRole) {
        this.username = username;
        this.encryptedPassword = encryptedPassword;
        this.securityRole = securityRole;
        this.isAccountActive = true;
    }

    // Getters and Setters
    public String getUserId() { return userId; }
    public void setUserId(String userId) { this.userId = userId; }
    public String getUsername() { return username; }
    public void setUsername(String username) { this.username = username; }
    public String getEncryptedPassword() { return encryptedPassword; }
    public void setEncryptedPassword(String encryptedPassword) { this.encryptedPassword = encryptedPassword; }
    public String getSecurityRole() { return securityRole; }
    public void setSecurityRole(String securityRole) { this.securityRole = securityRole; }
    public Boolean getIsAccountActive() { return isAccountActive; }
    public void setIsAccountActive(Boolean isAccountActive) { this.isAccountActive = isAccountActive; }
}