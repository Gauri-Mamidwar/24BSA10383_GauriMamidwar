package com.example.collegemanagementsystem.api;

import com.example.collegemanagementsystem.business.CourseNodeService;
import com.example.collegemanagementsystem.domain.AdvancedCourseNode;
import com.example.collegemanagementsystem.dto.SystemEnrichedResponse;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import java.util.List;

@RestController
@RequestMapping("/api/v1/course-cluster")
@CrossOrigin(origins = "*")
public class CourseClusterApi {

    @Autowired
    private CourseNodeService courseService;

    @GetMapping
    public SystemEnrichedResponse<List<AdvancedCourseNode>> getAllCourses() {
        return new SystemEnrichedResponse<>(courseService.fetchAllCourses());
    }

    @PostMapping
    public SystemEnrichedResponse<AdvancedCourseNode> createCourseNode(@RequestBody AdvancedCourseNode course) {
        return new SystemEnrichedResponse<>(courseService.dynamicRegisterCourse(course));
    }

    @GetMapping("/faculty/{facultyId}")
    public SystemEnrichedResponse<List<AdvancedCourseNode>> getCoursesByFacultyNode(@PathVariable String facultyId) {
        return new SystemEnrichedResponse<>(courseService.fetchCoursesByFaculty(facultyId));
    }

    @DeleteMapping("/{id}")
    public SystemEnrichedResponse<String> deleteCourseNode(@PathVariable String id) {
        courseService.removeCourseNode(id);
        return new SystemEnrichedResponse<>("⚡ Core Alert: Course node registry completely flushed.");
    }
}
