package com.example.collegemanagementsystem.api;

import com.example.collegemanagementsystem.business.AttendanceAnalyticsService;
import com.example.collegemanagementsystem.domain.AcademicAttendanceTracker;
import com.example.collegemanagementsystem.dto.SystemEnrichedResponse;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import java.util.List;

@RestController
@RequestMapping("/api/v1/attendance-analytics")
@CrossOrigin(origins = "*") // Framework level dynamic CORS support
public class AttendanceAnalyticsApi {

    @Autowired
    private AttendanceAnalyticsService analyticsService;

    // 1. POST: http://localhost:8080/api/v1/attendance-analytics/log
    // Faculty through direct backend node isko trigger kar sakte hain
    @PostMapping("/log")
    public SystemEnrichedResponse<AcademicAttendanceTracker> processAttendanceLog(@RequestBody AcademicAttendanceTracker logData) {
        AcademicAttendanceTracker savedNode = analyticsService.logAttendanceNode(logData);
        return new SystemEnrichedResponse<>(savedNode);
    }

    // 2. GET HISTORY: http://localhost:8080/api/v1/attendance-analytics/student/{studentId}
    @GetMapping("/student/{studentId}")
    public SystemEnrichedResponse<List<AcademicAttendanceTracker>> getStudentAttendanceHistory(@PathVariable String studentId) {
        List<AcademicAttendanceTracker> logsList = analyticsService.fetchStudentAttendanceLogs(studentId);
        return new SystemEnrichedResponse<>(logsList);
    }

    // 3. GET LIVE PERCENTAGE: http://localhost:8080/api/v1/attendance-analytics/percentage/{studentId}
    // Brain of the system: Realtime calculation on database node values
    @GetMapping("/percentage/{studentId}")
    public SystemEnrichedResponse<Double> getLiveAttendanceEvaluation(@PathVariable String studentId) {
        Double calculatedPercentage = analyticsService.calculateLiveAttendancePercentage(studentId);
        return new SystemEnrichedResponse<>(calculatedPercentage);
    }
}