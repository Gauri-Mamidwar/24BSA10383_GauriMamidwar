package com.example.collegemanagementsystem.domain;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;
import java.time.LocalDate;

@Document(collection = "attendance_analytics")
public class AcademicAttendanceTracker {
    @Id
    private String trackerId;
    private String targetStudentId;       // Linked to AdvancedStudent ID
    private String targetCourseId;        // Linked to Course/Subject Identifier
    private LocalDate operationalDate;    // Date of the class
    private String enrollmentStatus;      // PRESENT, ABSENT, MEDICAL_LEAVE

    // Constructors
    public AcademicAttendanceTracker() {}

    public AcademicAttendanceTracker(String targetStudentId, String targetCourseId, LocalDate operationalDate, String enrollmentStatus) {
        this.targetStudentId = targetStudentId;
        this.targetCourseId = targetCourseId;
        this.operationalDate = operationalDate;
        this.enrollmentStatus = enrollmentStatus;
    }

    // Getters and Setters
    public String getTrackerId() { return trackerId; }
    public void setTrackerId(String trackerId) { this.trackerId = trackerId; }
    public String getTargetStudentId() { return targetStudentId; }
    public void setTargetStudentId(String targetStudentId) { this.targetStudentId = targetStudentId; }
    public String getTargetCourseId() { return targetCourseId; }
    public void setTargetCourseId(String targetCourseId) { this.targetCourseId = targetCourseId; }
    public LocalDate getOperationalDate() { return operationalDate; }
    public void setOperationalDate(LocalDate operationalDate) { this.operationalDate = operationalDate; }
    public String getEnrollmentStatus() { return enrollmentStatus; }
    public void setEnrollmentStatus(String enrollmentStatus) { this.enrollmentStatus = enrollmentStatus; }
}