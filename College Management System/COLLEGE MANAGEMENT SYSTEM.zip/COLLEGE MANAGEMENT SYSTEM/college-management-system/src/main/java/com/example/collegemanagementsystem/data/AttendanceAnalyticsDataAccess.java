package com.example.collegemanagementsystem.data;

import com.example.collegemanagementsystem.domain.AcademicAttendanceTracker;
import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.stereotype.Repository;
import java.util.List;

@Repository
public interface AttendanceAnalyticsDataAccess extends MongoRepository<AcademicAttendanceTracker, String> {

    // Custom analytics mapping queries
    List<AcademicAttendanceTracker> findByTargetStudentId(String targetStudentId);

    // Core counter for calculating live percentage
    long countByTargetStudentIdAndEnrollmentStatus(String targetStudentId, String enrollmentStatus);
}