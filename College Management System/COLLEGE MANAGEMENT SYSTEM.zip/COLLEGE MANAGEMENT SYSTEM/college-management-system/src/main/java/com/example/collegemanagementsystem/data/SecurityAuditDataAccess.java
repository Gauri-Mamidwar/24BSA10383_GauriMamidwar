package com.example.collegemanagementsystem.data;

import com.example.collegemanagementsystem.domain.SecurityAuditLogger;
import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.stereotype.Repository;
import java.util.List;

@Repository
public interface SecurityAuditDataAccess extends MongoRepository<SecurityAuditLogger, String> {
    List<SecurityAuditLogger> findByTargetedUsername(String targetedUsername);
}