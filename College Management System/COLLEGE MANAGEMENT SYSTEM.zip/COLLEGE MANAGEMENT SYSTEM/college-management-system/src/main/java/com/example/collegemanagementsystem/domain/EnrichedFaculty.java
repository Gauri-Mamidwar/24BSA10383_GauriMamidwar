package com.example.collegemanagementsystem.domain;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

@Document(collection = "faculty_cluster")
public class EnrichedFaculty {
    @Id
    private String facultyId;
    private String facultyName;
    private String officialEmail;
    private String academicDesignation; // HOD, Senior Professor, Tech Lead
    private String assignedDepartmentId; // Linked to AdvancedDepartment ID
    private Double coreRemuneration;     // Salary
    private String coreSpecialization;   // AI, Cloud, Data Science

    // Constructors
    public EnrichedFaculty() {}

    public EnrichedFaculty(String facultyName, String officialEmail, String academicDesignation, String assignedDepartmentId, Double coreRemuneration, String coreSpecialization) {
        this.facultyName = facultyName;
        this.officialEmail = officialEmail;
        this.academicDesignation = academicDesignation;
        this.assignedDepartmentId = assignedDepartmentId;
        this.coreRemuneration = coreRemuneration;
        this.coreSpecialization = coreSpecialization;
    }

    // Getters and Setters
    public String getFacultyId() { return facultyId; }
    public void setFacultyId(String facultyId) { this.facultyId = facultyId; }
    public String getFacultyName() { return facultyName; }
    public void setFacultyName(String facultyName) { this.facultyName = facultyName; }
    public String getOfficialEmail() { return officialEmail; }
    public void setOfficialEmail(String officialEmail) { this.officialEmail = officialEmail; }
    public String getAcademicDesignation() { return academicDesignation; }
    public void setAcademicDesignation(String academicDesignation) { this.academicDesignation = academicDesignation; }
    public String getAssignedDepartmentId() { return assignedDepartmentId; }
    public void setAssignedDepartmentId(String assignedDepartmentId) { this.assignedDepartmentId = assignedDepartmentId; }
    public Double getCoreRemuneration() { return coreRemuneration; }
    public void setCoreRemuneration(Double coreRemuneration) { this.coreRemuneration = coreRemuneration; }
    public String getCoreSpecialization() { return coreSpecialization; }
    public void setCoreSpecialization(String coreSpecialization) { this.coreSpecialization = coreSpecialization; }
}