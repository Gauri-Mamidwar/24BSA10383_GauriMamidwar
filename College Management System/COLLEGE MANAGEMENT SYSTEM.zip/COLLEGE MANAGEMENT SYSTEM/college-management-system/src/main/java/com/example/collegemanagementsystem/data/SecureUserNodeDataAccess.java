package com.example.collegemanagementsystem.data;

import com.example.collegemanagementsystem.domain.SecureUserRegistry;
import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.stereotype.Repository;
import java.util.Optional;

@Repository
public interface SecureUserNodeDataAccess extends MongoRepository<SecureUserRegistry, String> {
    Optional<SecureUserRegistry> findByUsername(String username);
}