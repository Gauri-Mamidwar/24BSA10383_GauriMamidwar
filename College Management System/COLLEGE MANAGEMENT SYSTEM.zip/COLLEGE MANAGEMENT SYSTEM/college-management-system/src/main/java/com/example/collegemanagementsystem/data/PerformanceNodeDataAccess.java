package com.example.collegemanagementsystem.data;

import com.example.collegemanagementsystem.domain.AcademicPerformanceNode;
import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.stereotype.Repository;
import java.util.List;

@Repository
public interface PerformanceNodeDataAccess extends MongoRepository<AcademicPerformanceNode, String> {
    // Custom query to fetch all subject grades for a single student
    List<AcademicPerformanceNode> findByStudentId(String studentId);
}
