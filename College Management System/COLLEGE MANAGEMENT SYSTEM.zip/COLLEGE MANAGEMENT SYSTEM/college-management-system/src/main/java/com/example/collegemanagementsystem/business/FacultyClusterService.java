package com.example.collegemanagementsystem.business;

import com.example.collegemanagementsystem.data.FacultyClusterDataAccess;
import com.example.collegemanagementsystem.domain.EnrichedFaculty;
import com.example.collegemanagementsystem.exception.ResourceNotFoundException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.util.List;

@Service
public class FacultyClusterService {

    @Autowired
    private FacultyClusterDataAccess facultyDataAccess;

    // 1. Pure faculty cluster ka data fetch karna
    public List<EnrichedFaculty> fetchAllFaculty() {
        return facultyDataAccess.findAll();
    }

    // 2. Naya secure faculty node system me register karna
    public EnrichedFaculty registerFaculty(EnrichedFaculty faculty) {
        return facultyDataAccess.save(faculty);
    }

    // 3. Kisi specific department ke saare faculty members ko track karna
    public List<EnrichedFaculty> fetchFacultyByDepartment(String deptId) {
        return facultyDataAccess.findByAssignedDepartmentId(deptId);
    }

    // 4. Faculty core profile update karna (Advanced Node Merge)
    public EnrichedFaculty updateFacultyProfile(String id, EnrichedFaculty incomingDetails) {
        return facultyDataAccess.findById(id).map(existingFaculty -> {
            existingFaculty.setFacultyName(incomingDetails.getFacultyName());
            existingFaculty.setOfficialEmail(incomingDetails.getOfficialEmail());
            existingFaculty.setAcademicDesignation(incomingDetails.getAcademicDesignation());
            existingFaculty.setCoreRemuneration(incomingDetails.getCoreRemuneration());
            existingFaculty.setCoreSpecialization(incomingDetails.getCoreSpecialization());
            return facultyDataAccess.save(existingFaculty);
        }).orElseThrow(() -> new ResourceNotFoundException("Faculty Node not found with Identifier: " + id));
    }

    // 5. Faculty profile registry se wipe out karna
    public void terminateFacultyRecord(String id) {
        if (!facultyDataAccess.existsById(id)) {
            throw new ResourceNotFoundException("Cannot delete. Faculty Node does not exist: " + id);
        }
        facultyDataAccess.deleteById(id);
    }
}