package com.example.collegemanagementsystem.business;

import com.example.collegemanagementsystem.data.CourseNodeDataAccess;
import com.example.collegemanagementsystem.domain.AdvancedCourseNode;
import com.example.collegemanagementsystem.exception.ResourceNotFoundException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.util.List;

@Service
public class CourseNodeService {

    @Autowired
    private CourseNodeDataAccess courseDataAccess;

    public List<AdvancedCourseNode> fetchAllCourses() {
        return courseDataAccess.findAll();
    }

    public AdvancedCourseNode dynamicRegisterCourse(AdvancedCourseNode course) {
        return courseDataAccess.save(course);
    }

    public List<AdvancedCourseNode> fetchCoursesByFaculty(String facultyId) {
        return courseDataAccess.findByHandlingFacultyId(facultyId);
    }

    public void removeCourseNode(String id) {
        if (!courseDataAccess.existsById(id)) {
            throw new ResourceNotFoundException("Course cluster node not found for erasure: " + id);
        }
        courseDataAccess.deleteById(id);
    }
}