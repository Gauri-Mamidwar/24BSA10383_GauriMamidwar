package com.example.collegemanagementsystem.business;

import com.example.collegemanagementsystem.data.AttendanceAnalyticsDataAccess;
import com.example.collegemanagementsystem.domain.AcademicAttendanceTracker;
import com.example.collegemanagementsystem.exception.ResourceNotFoundException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.util.List;

@Service
public class AttendanceAnalyticsService {

    @Autowired
    private AttendanceAnalyticsDataAccess analyticsDataAccess;

    // 1. Live Class Attendance Registry record karna
    public AcademicAttendanceTracker logAttendanceNode(AcademicAttendanceTracker trackerNode) {
        return analyticsDataAccess.save(trackerNode);
    }

    // 2. Kisi specific student ka poora attendance history fetch karna
    public List<AcademicAttendanceTracker> fetchStudentAttendanceLogs(String studentId) {
        return analyticsDataAccess.findByTargetStudentId(studentId);
    }

    // 3. 🧠 DYNAMIC ANALYTICS ENGINE: Student ka dynamic percentage calculate karna
    public double calculateLiveAttendancePercentage(String studentId) {
        List<AcademicAttendanceTracker> totalClasses = analyticsDataAccess.findByTargetStudentId(studentId);

        // Agar abhi tak koi class hi nahi hui, toh automatic 100% display karega
        if (totalClasses.isEmpty()) {
            return 100.0;
        }

        // Live counts criteria from MongoDB Atlas cluster
        long presentCount = analyticsDataAccess.countByTargetStudentIdAndEnrollmentStatus(studentId, "PRESENT");

        // Final Core Performance Calculation formula
        return ((double) presentCount / totalClasses.size()) * 100.0;
    }
}