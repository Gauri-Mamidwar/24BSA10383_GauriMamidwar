package com.example.collegemanagementsystem.domain;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;
import java.time.LocalDateTime;

@Document(collection = "security_audit_logs")
public class SecurityAuditLogger {
    @Id
    private String logId;
    private String targetedUsername;
    private LocalDateTime executionTimestamp;
    private String authenticationStatus; // SUCCESS, BAD_CREDENTIALS

    public SecurityAuditLogger() {}

    public SecurityAuditLogger(String targetedUsername, String authenticationStatus) {
        this.targetedUsername = targetedUsername;
        this.executionTimestamp = LocalDateTime.now();
        this.authenticationStatus = authenticationStatus;
    }

    // Getters and Setters
    public String getLogId() { return logId; }
    public void setLogId(String logId) { this.logId = logId; }
    public String getTargetedUsername() { return targetedUsername; }
    public void setTargetedUsername(String targetedUsername) { this.targetedUsername = targetedUsername; }
    public LocalDateTime getExecutionTimestamp() { return executionTimestamp; }
    public void setExecutionTimestamp(LocalDateTime executionTimestamp) { this.executionTimestamp = executionTimestamp; }
    public String getAuthenticationStatus() { return authenticationStatus; }
    public void setAuthenticationStatus(String authenticationStatus) { this.authenticationStatus = authenticationStatus; }
}