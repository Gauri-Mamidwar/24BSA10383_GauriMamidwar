package com.example.collegemanagementsystem.domain;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

@Document(collection = "performance_registry")
public class AcademicPerformanceNode {
    @Id
    private String evaluationId;
    private String studentId;        // Linked to AdvancedStudent ID
    private String courseId;         // Linked to AdvancedCourseNode ID
    private Double internalMarks;    // Out of 30
    private Double externalMarks;    // Out of 70
    private Double totalAggregate;   // Out of 100 (Calculated automatically)
    private String finalLetterGrade; // A+, A, B, F (Calculated automatically)

    public AcademicPerformanceNode() {}

    public AcademicPerformanceNode(String studentId, String courseId, Double internalMarks, Double externalMarks) {
        this.studentId = studentId;
        this.courseId = courseId;
        this.internalMarks = internalMarks;
        this.externalMarks = externalMarks;
        this.totalAggregate = internalMarks + externalMarks;
    }

    // Getters and Setters
    public String getEvaluationId() { return evaluationId; }
    public void setEvaluationId(String evaluationId) { this.evaluationId = evaluationId; }
    public String getStudentId() { return studentId; }
    public void setStudentId(String studentId) { this.studentId = studentId; }
    public String getCourseId() { return courseId; }
    public void setCourseId(String courseId) { this.courseId = courseId; }
    public Double getInternalMarks() { return internalMarks; }
    public void setInternalMarks(Double internalMarks) { this.internalMarks = internalMarks; }
    public Double getExternalMarks() { return externalMarks; }
    public void setExternalMarks(Double externalMarks) { this.externalMarks = externalMarks; }
    public Double getTotalAggregate() { return totalAggregate; }
    public void setTotalAggregate(Double totalAggregate) { this.totalAggregate = totalAggregate; }
    public String getFinalLetterGrade() { return finalLetterGrade; }
    public void setFinalLetterGrade(String finalLetterGrade) { this.finalLetterGrade = finalLetterGrade; }
}
