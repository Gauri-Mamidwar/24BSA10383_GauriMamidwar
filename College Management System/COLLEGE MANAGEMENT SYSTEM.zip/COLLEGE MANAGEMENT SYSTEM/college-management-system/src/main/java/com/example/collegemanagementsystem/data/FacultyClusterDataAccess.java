package com.example.collegemanagementsystem.data;

import com.example.collegemanagementsystem.domain.EnrichedFaculty;
import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.stereotype.Repository;
import java.util.List;

@Repository
public interface FacultyClusterDataAccess extends MongoRepository<EnrichedFaculty, String> {
    // Custom cluster filter mapping
    List<EnrichedFaculty> findByAssignedDepartmentId(String assignedDepartmentId);
}