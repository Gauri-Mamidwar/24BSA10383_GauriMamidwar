package com.example.collegemanagementsystem.api;

import com.example.collegemanagementsystem.business.IdentityAccessManagementService;
import com.example.collegemanagementsystem.domain.SecureUserRegistry;
import com.example.collegemanagementsystem.domain.SecurityAuditLogger;
import com.example.collegemanagementsystem.dto.SystemEnrichedResponse;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import java.util.List;

@RestController
@RequestMapping("/api/v1/iam-gateway")
@CrossOrigin(origins = "*")
public class IdentityAccessManagementApi {

    @Autowired
    private IdentityAccessManagementService iamService;

    // Signup Gate
    @PostMapping("/register")
    public SystemEnrichedResponse<SecureUserRegistry> createSystemProfile(@RequestBody SecureUserRegistry newUser) {
        return new SystemEnrichedResponse<>(iamService.registerSecureAccount(newUser));
    }

    // Login Gate
    @PostMapping("/login")
    public SystemEnrichedResponse<String> verifySystemIdentity(@RequestParam String username, @RequestParam String credentialKey) {
        String resolutionMessage = iamService.authenticateCredentialToken(username, credentialKey);
        return new SystemEnrichedResponse<>(resolutionMessage);
    }

    // Audit Inspection Node
    @GetMapping("/audit-logs/{username}")
    public SystemEnrichedResponse<List<SecurityAuditLogger>> extractProfileAuditLogs(@PathVariable String username) {
        return new SystemEnrichedResponse<>(iamService.fetchLogsByAccount(username));
    }
}
