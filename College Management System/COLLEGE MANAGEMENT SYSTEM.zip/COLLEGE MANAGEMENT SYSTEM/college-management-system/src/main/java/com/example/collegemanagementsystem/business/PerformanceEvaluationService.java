package com.example.collegemanagementsystem.business;

import com.example.collegemanagementsystem.data.PerformanceNodeDataAccess;
import com.example.collegemanagementsystem.domain.AcademicPerformanceNode;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.util.List;

@Service
public class PerformanceEvaluationService {

    @Autowired
    private PerformanceNodeDataAccess performanceDataAccess;

    // 🧠 AUTOMATED ENGINE: Marks add hote hi automatic grade check karega
    public AcademicPerformanceNode uploadAndEvaluateMarks(AcademicPerformanceNode performance) {
        double total = performance.getInternalMarks() + performance.getExternalMarks();
        performance.setTotalAggregate(total);

        // Grade Calculator Matrix
        if (total >= 90) performance.setFinalLetterGrade("A+");
        else if (total >= 80) performance.setFinalLetterGrade("A");
        else if (total >= 70) performance.setFinalLetterGrade("B");
        else if (total >= 60) performance.setFinalLetterGrade("C");
        else if (total >= 40) performance.setFinalLetterGrade("D");
        else performance.setFinalLetterGrade("F (FAIL)");

        return performanceDataAccess.save(performance);
    }

    public List<AcademicPerformanceNode> fetchReportCard(String studentId) {
        return performanceDataAccess.findByStudentId(studentId);
    }

    // 📊 CGPA GENERATOR ENGINE
    public double calculateDynamicCGPA(String studentId) {
        List<AcademicPerformanceNode> records = performanceDataAccess.findByStudentId(studentId);
        if (records.isEmpty()) return 0.0;

        double totalPoints = 0.0;
        for (AcademicPerformanceNode node : records) {
            double aggregate = node.getTotalAggregate();
            totalPoints += (aggregate / 10.0); // Convert to 10-point scale
        }
        return totalPoints / records.size();
    }
}