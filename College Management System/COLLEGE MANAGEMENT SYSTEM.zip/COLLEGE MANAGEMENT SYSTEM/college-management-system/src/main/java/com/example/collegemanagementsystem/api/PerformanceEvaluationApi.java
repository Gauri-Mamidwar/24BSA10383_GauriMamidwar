package com.example.collegemanagementsystem.api;

import com.example.collegemanagementsystem.business.PerformanceEvaluationService;
import com.example.collegemanagementsystem.domain.AcademicPerformanceNode;
import com.example.collegemanagementsystem.dto.SystemEnrichedResponse;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import java.util.List;

@RestController
@RequestMapping("/api/v1/performance-evaluation")
@CrossOrigin(origins = "*")
public class PerformanceEvaluationApi {

    @Autowired
    private PerformanceEvaluationService evaluationService;

    // 1. POST: http://localhost:8080/api/v1/performance-evaluation/upload
    @PostMapping("/upload")
    public SystemEnrichedResponse<AcademicPerformanceNode> uploadStudentMarks(@RequestBody AcademicPerformanceNode performance) {
        return new SystemEnrichedResponse<>(evaluationService.uploadAndEvaluateMarks(performance));
    }

    // 2. GET REPORT: http://localhost:8080/api/v1/performance-evaluation/report-card/{studentId}
    @GetMapping("/report-card/{studentId}")
    public SystemEnrichedResponse<List<AcademicPerformanceNode>> getStudentReportCard(@PathVariable String studentId) {
        return new SystemEnrichedResponse<>(evaluationService.fetchReportCard(studentId));
    }

    // 3. GET CGPA: http://localhost:8080/api/v1/performance-evaluation/cgpa/{studentId}
    @GetMapping("/cgpa/{studentId}")
    public SystemEnrichedResponse<Double> getLiveGpaEvaluation(@PathVariable String studentId) {
        return new SystemEnrichedResponse<>(evaluationService.calculateDynamicCGPA(studentId));
    }
}