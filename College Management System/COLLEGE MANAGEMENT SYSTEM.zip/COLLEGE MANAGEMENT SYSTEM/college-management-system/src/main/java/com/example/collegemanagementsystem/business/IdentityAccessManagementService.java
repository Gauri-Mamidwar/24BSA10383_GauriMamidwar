package com.example.collegemanagementsystem.business;

import com.example.collegemanagementsystem.data.SecureUserNodeDataAccess;
import com.example.collegemanagementsystem.data.SecurityAuditDataAccess;
import com.example.collegemanagementsystem.domain.SecureUserRegistry;
import com.example.collegemanagementsystem.domain.SecurityAuditLogger;
import com.example.collegemanagementsystem.exception.ResourceNotFoundException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.util.List;
import java.util.Optional;

@Service
public class IdentityAccessManagementService {

    @Autowired
    private SecureUserNodeDataAccess userDataAccess;

    @Autowired
    private SecurityAuditDataAccess auditDataAccess;

    // User Registration Node
    public SecureUserRegistry registerSecureAccount(SecureUserRegistry user) {
        // Real corporate standard check to prevent duplicate profiles
        Optional<SecureUserRegistry> existing = userDataAccess.findByUsername(user.getUsername());
        if(existing.isPresent()) {
            throw new RuntimeException("⚡ Access Denied: Identity Cluster node already contains username: " + user.getUsername());
        }
        return userDataAccess.save(user);
    }

    // Dynamic Verification & Audit Engine
    public String authenticateCredentialToken(String username, String rawPassword) {
        SecureUserRegistry user = userDataAccess.findByUsername(username)
                .orElseThrow(() -> {
                    auditDataAccess.save(new SecurityAuditLogger(username, "INVALID_USERNAME"));
                    return new ResourceNotFoundException("Identity credentials mismatch for entity: " + username);
                });

        if (user.getEncryptedPassword().equals(rawPassword)) {
            auditDataAccess.save(new SecurityAuditLogger(username, "SUCCESS"));
            return "🔐 Access Token Granted. Session Active for Role Cluster: " + user.getSecurityRole();
        } else {
            auditDataAccess.save(new SecurityAuditLogger(username, "BAD_CREDENTIALS"));
            throw new RuntimeException("⚡ Security Breach: Invalid Token Matrix or secret phrase.");
        }
    }

    public List<SecurityAuditLogger> fetchLogsByAccount(String username) {
        return auditDataAccess.findByTargetedUsername(username);
    }
}