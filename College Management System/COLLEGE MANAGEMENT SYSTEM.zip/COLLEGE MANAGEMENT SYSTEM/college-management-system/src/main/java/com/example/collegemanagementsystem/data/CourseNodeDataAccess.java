package com.example.collegemanagementsystem.data;

import com.example.collegemanagementsystem.domain.AdvancedCourseNode;
import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.stereotype.Repository;
import java.util.List;

@Repository
public interface CourseNodeDataAccess extends MongoRepository<AdvancedCourseNode, String> {
    // Custom filter faculty wise courses tracking
    List<AdvancedCourseNode> findByHandlingFacultyId(String handlingFacultyId);
}