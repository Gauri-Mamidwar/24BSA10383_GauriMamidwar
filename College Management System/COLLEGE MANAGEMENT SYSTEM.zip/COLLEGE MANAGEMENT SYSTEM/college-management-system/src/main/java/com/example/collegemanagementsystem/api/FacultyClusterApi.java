package com.example.collegemanagementsystem.api;

import com.example.collegemanagementsystem.business.FacultyClusterService;
import com.example.collegemanagementsystem.domain.EnrichedFaculty;
import com.example.collegemanagementsystem.dto.SystemEnrichedResponse;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import java.util.List;

@RestController
@RequestMapping("/api/v1/faculty-cluster")
@CrossOrigin(origins = "*") // Master CORS configuration for seamless UI connection
public class FacultyClusterApi {

    @Autowired
    private FacultyClusterService facultyService;

    // 1. GET: http://localhost:8080/api/v1/faculty-cluster
    @GetMapping
    public SystemEnrichedResponse<List<EnrichedFaculty>> getAllFacultyNodes() {
        List<EnrichedFaculty> facultyList = facultyService.fetchAllFaculty();
        return new SystemEnrichedResponse<>(facultyList);
    }

    // 2. POST: http://localhost:8080/api/v1/faculty-cluster
    @PostMapping
    public SystemEnrichedResponse<EnrichedFaculty> addNewFacultyNode(@RequestBody EnrichedFaculty faculty) {
        EnrichedFaculty savedFaculty = facultyService.registerFaculty(faculty);
        return new SystemEnrichedResponse<>(savedFaculty);
    }

    // 3. GET BY DEPT: http://localhost:8080/api/v1/faculty-cluster/department/{deptId}
    @GetMapping("/department/{departmentId}")
    public SystemEnrichedResponse<List<EnrichedFaculty>> getFacultyByDepartmentCluster(@PathVariable String departmentId) {
        List<EnrichedFaculty> operationalList = facultyService.fetchFacultyByDepartment(departmentId);
        return new SystemEnrichedResponse<>(operationalList);
    }

    // 4. PUT: http://localhost:8080/api/v1/faculty-cluster/{id}
    @PutMapping("/{id}")
    public SystemEnrichedResponse<EnrichedFaculty> updateFacultyNodeProfile(@PathVariable String id, @RequestBody EnrichedFaculty facultyDetails) {
        EnrichedFaculty updatedFaculty = facultyService.updateFacultyProfile(id, facultyDetails);
        return new SystemEnrichedResponse<>(updatedFaculty);
    }

    // 5. DELETE: http://localhost:8080/api/v1/faculty-cluster/{id}
    @DeleteMapping("/{id}")
    public SystemEnrichedResponse<String> terminateFacultyNode(@PathVariable String id) {
        facultyService.terminateFacultyRecord(id);
        return new SystemEnrichedResponse<>("⚡ Core Alert: Faculty cluster node and dependent schemas completely wiped.");
    }
}