package com.example.collegemanagementsystem.domain;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

@Document(collection = "academic_courses")
public class AdvancedCourseNode {
    @Id
    private String courseId;
    private String courseName;
    private String courseCode;       // Jaise: CS-301, AI-402
    private Integer academicCredits; // 3 Credits, 4 Credits
    private String handlingFacultyId; // Linked to EnrichedFaculty ID

    public AdvancedCourseNode() {}

    public AdvancedCourseNode(String courseName, String courseCode, Integer academicCredits, String handlingFacultyId) {
        this.courseName = courseName;
        this.courseCode = courseCode;
        this.academicCredits = academicCredits;
        this.handlingFacultyId = handlingFacultyId;
    }

    // Getters and Setters
    public String getCourseId() { return courseId; }
    public void setCourseId(String courseId) { this.courseId = courseId; }
    public String getCourseName() { return courseName; }
    public void setCourseName(String courseName) { this.courseName = courseName; }
    public String getCourseCode() { return courseCode; }
    public void setCourseCode(String courseCode) { this.courseCode = courseCode; }
    public Integer getAcademicCredits() { return academicCredits; }
    public void setAcademicCredits(Integer academicCredits) { this.academicCredits = academicCredits; }
    public String getHandlingFacultyId() { return handlingFacultyId; }
    public void setHandlingFacultyId(String handlingFacultyId) { this.handlingFacultyId = handlingFacultyId; }
}