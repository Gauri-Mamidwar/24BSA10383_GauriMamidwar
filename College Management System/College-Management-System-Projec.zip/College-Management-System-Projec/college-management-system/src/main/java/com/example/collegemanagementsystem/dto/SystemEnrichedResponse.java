package com.example.collegemanagementsystem.dto;

import java.util.Date;

public class SystemEnrichedResponse<T> {
    private Date systemTimestamp;
    private String dataIntegrityToken;
    private T payload;

    public SystemEnrichedResponse(T payload) {
        this.systemTimestamp = new Date();
        this.dataIntegrityToken = "SECURE_SHA256_" + System.currentTimeMillis();
        this.payload = payload;
    }

    // Getters
    public Date getSystemTimestamp() { return systemTimestamp; }
    public String getDataIntegrityToken() { return dataIntegrityToken; }
    public T getPayload() { return payload; }
}