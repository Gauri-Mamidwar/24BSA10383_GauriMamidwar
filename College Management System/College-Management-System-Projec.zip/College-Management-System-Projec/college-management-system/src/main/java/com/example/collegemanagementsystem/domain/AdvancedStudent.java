package com.example.collegemanagementsystem.domain;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;
import java.util.ArrayList;
import java.util.List;

@Document(collection = "advanced_students")
public class AdvancedStudent {
    @Id
    private String id;
    private String studentName;
    private String rollNumber;
    private String emailAddress;
    private String assignedDeptId;
    private List<String> registeredCourseNames = new ArrayList<>();

    // Getters and Setters
    public String getId() { return id; }
    public void setId(String id) { this.id = id; }
    public String getStudentName() { return studentName; }
    public void setStudentName(String studentName) { this.studentName = studentName; }
    public String getRollNumber() { return rollNumber; }
    public void setRollNumber(String rollNumber) { this.rollNumber = rollNumber; }
    public String getEmailAddress() { return emailAddress; }
    public void setEmailAddress(String emailAddress) { this.emailAddress = emailAddress; }
    public String getAssignedDeptId() { return assignedDeptId; }
    public void setAssignedDeptId(String assignedDeptId) { this.assignedDeptId = assignedDeptId; }
    public List<String> getRegisteredCourseNames() { return registeredCourseNames; }
    public void setRegisteredCourseNames(List<String> registeredCourseNames) { this.registeredCourseNames = registeredCourseNames; }
}