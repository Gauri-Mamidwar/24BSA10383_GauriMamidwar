package com.example.collegemanagementsystem.data;

import com.example.collegemanagementsystem.domain.AdvancedStudent;
import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface StudentDataAccess extends MongoRepository<AdvancedStudent, String> {
}