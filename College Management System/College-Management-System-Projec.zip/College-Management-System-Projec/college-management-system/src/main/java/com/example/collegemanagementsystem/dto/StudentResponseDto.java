package com.example.collegemanagementsystem.dto;

import java.util.List;

public class StudentResponseDto {
    private String id;
    private String studentName;
    private String rollNumber;
    private String emailAddress;
    private List<String> registeredCourseNames;
    private String executionStatus;

    // Getters and Setters
    public String getId() { return id; }
    public void setId(String id) { this.id = id; }

    public String getStudentName() { return studentName; }
    public void setStudentName(String studentName) { this.studentName = studentName; }

    public String getRollNumber() { return rollNumber; }
    public void setRollNumber(String rollNumber) { this.rollNumber = rollNumber; }

    public String getEmailAddress() { return emailAddress; }
    public void setEmailAddress(String emailAddress) { this.emailAddress = emailAddress; }

    public List<String> getRegisteredCourseNames() { return registeredCourseNames; }
    public void setRegisteredCourseNames(List<String> registeredCourseNames) { this.registeredCourseNames = registeredCourseNames; }

    public String getExecutionStatus() { return executionStatus; }
    public void setExecutionStatus(String executionStatus) { this.executionStatus = executionStatus; }
}