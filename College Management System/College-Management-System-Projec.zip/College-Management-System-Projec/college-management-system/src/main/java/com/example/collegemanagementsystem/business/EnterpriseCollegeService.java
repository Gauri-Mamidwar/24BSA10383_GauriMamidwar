package com.example.collegemanagementsystem.business;

import com.example.collegemanagementsystem.domain.AdvancedDepartment;
import com.example.collegemanagementsystem.domain.AdvancedStudent;
import com.example.collegemanagementsystem.data.DepartmentDataAccess;
import com.example.collegemanagementsystem.data.StudentDataAccess;
import com.example.collegemanagementsystem.dto.StudentResponseDto;
import com.example.collegemanagementsystem.exception.ResourceNotFoundException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.util.ArrayList;
import java.util.List;

@Service
public class EnterpriseCollegeService {

    @Autowired
    private DepartmentDataAccess deptData;

    @Autowired
    private StudentDataAccess studData;

    // 1. Create Department Engine
    public AdvancedDepartment createDepartment(AdvancedDepartment d) {
        return deptData.save(d);
    }

    // 2. Fetch All Departments
    public List<AdvancedDepartment> fetchAllDepartments() {
        return deptData.findAll();
    }

    // 3. Secure Wipeout Department
    public void removeDepartment(String id) {
        if(!deptData.existsById(id)) {
            throw new ResourceNotFoundException("Deletion Aborted: Department Ledger Record entry not found for ID: " + id);
        }
        deptData.deleteById(id);
    }

    // 4. Advanced Student Ingestion Engine
    public AdvancedStudent createStudent(AdvancedStudent s) {
        if(!deptData.existsById(s.getAssignedDeptId())) {
            throw new ResourceNotFoundException("Ingestion Refused: Assigned Parent Department ID " + s.getAssignedDeptId() + " does not exist inside MongoDB Cluster.");
        }
        return studData.save(s);
    }

    // 5. Fetch All Enrolled Students
    public List<AdvancedStudent> fetchAllStudents() {
        return studData.findAll();
    }

    // 6. Enterprise DTO Transformation Engine (Enriched Student Query)
    public StudentResponseDto fetchEnrichedStudentProfile(String studentId) {
        AdvancedStudent student = studData.findById(studentId)
                .orElseThrow(() -> new ResourceNotFoundException("Query Failed: Student Identity profile could not be verified for ID: " + studentId));

        StudentResponseDto dto = new StudentResponseDto();
        dto.setId(student.getId());
        dto.setStudentName(student.getStudentName());
        dto.setRollNumber(student.getRollNumber());
        dto.setEmailAddress(student.getEmailAddress());
        dto.setRegisteredCourseNames(student.getRegisteredCourseNames());
        dto.setExecutionStatus("VERIFIED_AND_ENRICHED_BY_CORE_SUBSYSTEM");
        return dto;
    }

    // 7. Dynamic Course Router Subsystem
    public AdvancedStudent allocateCourseToStudent(String studentId, String courseName) {
        AdvancedStudent student = studData.findById(studentId)
                .orElseThrow(() -> new ResourceNotFoundException("Routing Aborted: Target Student Identity verification failed for ID: " + studentId));

        if(student.getRegisteredCourseNames() == null) {
            student.setRegisteredCourseNames(new ArrayList<>());
        }
        student.getRegisteredCourseNames().add(courseName);
        return studData.save(student);
    }

    // 8. Secure Wipeout Student Ledger Entry
    public void removeStudent(String id) {
        if(!studData.existsById(id)) {
            throw new ResourceNotFoundException("Deletion Aborted: Student Identity record entry not discovered inside registry for ID: " + id);
        }
        studData.deleteById(id);
    }

    // 9. Update Department Engine
    public AdvancedDepartment updateDepartmentDetails(String id, AdvancedDepartment updatedDept) {
        AdvancedDepartment existingDept = deptData.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Mutation Failed: Target Department entity not discovered for ID: " + id));

        existingDept.setDeptName(updatedDept.getDeptName());
        existingDept.setDeptCode(updatedDept.getDeptCode());
        existingDept.setHodName(updatedDept.getHodName());
        return deptData.save(existingDept);
    }
}