package com.example.collegemanagementsystem.api;

import com.example.collegemanagementsystem.domain.AdvancedDepartment;
import com.example.collegemanagementsystem.domain.AdvancedStudent;
import com.example.collegemanagementsystem.business.EnterpriseCollegeService;
import com.example.collegemanagementsystem.dto.StudentResponseDto;
import com.example.collegemanagementsystem.dto.SystemEnrichedResponse;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import java.util.List;

@RestController
@CrossOrigin(origins = "*", allowedHeaders = "*")
@RequestMapping("/api/v2/enterprise")
public class EnterpriseCollegeApi {

    @Autowired
    private EnterpriseCollegeService enterpriseService;

    @PostMapping("/departments")
    public SystemEnrichedResponse<AdvancedDepartment> addDept(@RequestBody AdvancedDepartment d) {
        return new SystemEnrichedResponse<>(enterpriseService.createDepartment(d));
    }

    @GetMapping("/departments")
    public SystemEnrichedResponse<List<AdvancedDepartment>> getDepts() {
        return new SystemEnrichedResponse<>(enterpriseService.fetchAllDepartments());
    }

    @DeleteMapping("/departments/{id}")
    public SystemEnrichedResponse<String> deleteDept(@PathVariable String id) {
        enterpriseService.removeDepartment(id);
        return new SystemEnrichedResponse<>("⚡ Core Alert: Department cluster and dependent schemas completely wiped.");
    }

    @PostMapping("/students")
    public SystemEnrichedResponse<AdvancedStudent> addStudent(@RequestBody AdvancedStudent s) {
        return new SystemEnrichedResponse<>(enterpriseService.createStudent(s));
    }

    @GetMapping("/students")
    public SystemEnrichedResponse<List<AdvancedStudent>> getStudents() {
        return new SystemEnrichedResponse<>(enterpriseService.fetchAllStudents());
    }

    // ⭐ NEW REST ENDPOINT: Fetches Enriched DTO Data Transfer Objects securely
    @GetMapping("/students/{id}/profile")
    public SystemEnrichedResponse<StudentResponseDto> getEnrichedStudentProfile(@PathVariable String id) {
        return new SystemEnrichedResponse<>(enterpriseService.fetchEnrichedStudentProfile(id));
    }

    @PutMapping("/students/{studentId}/allocate-course")
    public SystemEnrichedResponse<AdvancedStudent> assignCourse(@PathVariable String studentId, @RequestParam String courseName) {
        return new SystemEnrichedResponse<>(enterpriseService.allocateCourseToStudent(studentId, courseName));
    }

    @DeleteMapping("/students/{id}")
    public SystemEnrichedResponse<String> deleteStudent(@PathVariable String id) {
        enterpriseService.removeStudent(id);
        return new SystemEnrichedResponse<>("⚡ Core Alert: Student identity completely scrubbed from active ledger.");
    }

    @PutMapping("/departments/{id}")
    public SystemEnrichedResponse<AdvancedDepartment> modifyDept(@PathVariable String id, @RequestBody AdvancedDepartment d) {
        return new SystemEnrichedResponse<>(enterpriseService.updateDepartmentDetails(id, d));
    }
}