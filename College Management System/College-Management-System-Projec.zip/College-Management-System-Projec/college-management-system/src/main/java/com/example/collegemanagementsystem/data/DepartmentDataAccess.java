package com.example.collegemanagementsystem.data;

import com.example.collegemanagementsystem.domain.AdvancedDepartment;
import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface DepartmentDataAccess extends MongoRepository<AdvancedDepartment, String> {
}
