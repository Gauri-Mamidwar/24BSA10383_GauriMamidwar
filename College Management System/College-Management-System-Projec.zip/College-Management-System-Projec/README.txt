
      COLLEGE MANAGEMENT SYSTEM 

Student Details:
Name: Gauri Mamidwar
Registration Number: 24BSA10383
Date: June 16, 2026

Project Overview
This is a Full-Stack College Management System developed using Java Spring Boot for the backend and HTML, CSS, and JavaScript for the frontend dashboard. The application is integrated with a cloud-based MongoDB Atlas database to seamlessly handle live data transactions for Departments and Students.

1. Project Structure
The submitted ZIP folder contains the following setup:

College-Management-System-Project/
  backend/       Contains the complete Spring Boot Java Project (src/, pom.xml)
  frontend/      Contains the User Interface files (index.html)
  README.txt     This setup instruction file

2. Tech Stack Used
Backend Framework: Java Spring Boot
Database: MongoDB Atlas (Cloud Database)
Frontend: HTML5, CSS3, JavaScript (Vanilla JS)
API Connectivity: REST API Endpoints with enabled Cross-Origin Resource Sharing (CORS)

3. How to Run the Project (Instructions for Evaluation)

Step 1: Start the Backend Server
1. Open IntelliJ IDEA (or your preferred Java IDE).
2. Click on Open and select the backend folder from this project directory.
3. Allow Maven to fully import all dependencies from the pom.xml file.
4. Navigate to the main application file:
   src -> main -> java -> com -> example -> collegemanagementsystem -> CollegeManagementSystemApplication.java
5. Run the project by clicking the green Play button.
6. Check the console window. It will display "Started CollegeManagementSystemApplication" once it is successfully connected to the cloud and live.

Step 2: Start the Frontend Dashboard
1. Open the frontend folder from this project directory.
2. Simply double-click the index.html file.
3. It will instantly open the management dashboard in your default web browser (Chrome or Edge).

4. How to Test the System Flow

1. Adding a New Department
- Go to the web dashboard and click on the Department Ledger tab.
- Fill in the required fields (e.g., Department Full Name: Computer Science Engineering, Acronym / Code: CSE, HOD Name: Dr. R. K. Sharma).
- Click the green button labeled Initialize Department Node.
- The department record will immediately sync with the MongoDB cloud database and appear dynamically in the data table below.

2. Registering a Student Under That Department
- From the newly created department in the table, copy the unique 24-character alphanumeric string listed under Node ID.
- Switch over to the Student Subsystem tab.
- Enter the student details (Full Name, Roll Index, Email).
- Paste the copied 24-character ID directly into the Target Department Core ID input field.
- Click the blue button labeled Execute Ingestion.
- The student record will be successfully mapped and displayed under the selected department.

Note
Global CORS policies (@CrossOrigin(origins = "*")) have been configured in the Spring Boot controller to ensure seamless API connectivity. This allows the frontend to communicate with the backend directly from the local filesystem without any port locking or domain conflicts.